#ifndef __SP_UPLOAD_VALIDATION_H__
#define __SP_UPLOAD_VALIDATION_H__

void hook_upload(void);

#endif
