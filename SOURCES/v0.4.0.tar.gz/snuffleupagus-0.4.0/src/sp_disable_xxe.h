#ifndef __SP_DISABLE_XXE_H
#define __SP_DISABLE_XXE_H

int hook_libxml_disable_entity_loader();

#endif /* __SP_DISABLE_XXE_H */
