#ifndef SP_UNSERIALIZE_H
#define SP_UNSERIALIZE_H

int hook_serialize(void);

PHP_FUNCTION(sp_serialize);
PHP_FUNCTION(sp_unserialize);

#endif /* SP_UNSERIALIZE_H */
