#ifndef SP_WRAPPER_H
#define SP_WRAPPER_H
#include "php_snuffleupagus.h"

void sp_disable_wrapper(void);
int hook_stream_wrappers(void);

#endif
