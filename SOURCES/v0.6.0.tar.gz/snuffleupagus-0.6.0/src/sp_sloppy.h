#ifndef SP_SLOPPY_H
#define SP_SLOPPY_H
#include "php_snuffleupagus.h"
#include "zend_vm.h"

void hook_sloppy(void);

#endif
