Changelog
=========

0.6.0 - `Elephant in the room <https://github.com/jvoisin/snuffleupagus/releases/tag/v0.6.0>`__ 2020/11/06
----------------------------------------------------------------------------------------------------------

New features
^^^^^^^^^^^^
* Allow empty configurations

Improvements
^^^^^^^^^^^^

* More constification
* Snuffleupagus should now be able to get client's ip addresses in more cases
* Documented compatibility with Heroku
* Improved logging
* Added a couple of tests


0.5.1 - `Order of the Elephant <https://github.com/jvoisin/snuffleupagus/releases/tag/v0.5.1>`__ 2020/06/20
-----------------------------------------------------------------------------------------------------------

New features
^^^^^^^^^^^^
* Add support for syslog


Improvements
^^^^^^^^^^^^
* Improve OSX support
* Improve marginally of php8+ compatibility
* Improve php7.4 compatibility
* Improve the default ruleset
* Improve the documentation
* Improve the gitlab CI


0.5.0 - `Elephant Flats <https://github.com/jvoisin/snuffleupagus/releases/tag/v0.5.0>`__ 2019/06/12
----------------------------------------------------------------------------------------------------

Improvements
^^^^^^^^^^^^

- Tighten a bit a command-injection prevention rule in the default rules set
- Increased the portability of the testsuite
- Improved documentation
- Usual code cleanup
- Snuffleupagus will throw an informative error when compiled for PHP5
- Snuffleupagus will throw an informative error when compiled without PCRE support
- The testsuite is now run on Alpine, Fedora, Debian and Ubuntu.
- Some rules against now-known vulnerabilities/techniques were added


Bug fixes
^^^^^^^^^

- PHP7.4 is fully supported, without any compilation warning
- Snuffleupagus can now be used with PHP compiled without sessions support as a builtin (which is the case on Alpine).
- Fix a compilation warning on FreeBSD
- Cookies hardening is now supported on PHP7.3+



0.4.1 - `Loxodonta <https://github.com/jvoisin/snuffleupagus/releases/tag/v0.4.1>`__ 2018/12/21
-----------------------------------------------------------------------------------------------

Improvements
^^^^^^^^^^^^

- Improve and clarify the documentation
- Add support for PHP7.3
- Improve the coverage, we have reached 99% of coverage
- Improve `mb_string` hooking logic
- The script that check uploaded file is now available in PHP


Bug fixes
^^^^^^^^^

- Fix segfault on 32-bit for PHP7.3
- Fix segfault when using `sloppy_comparison` feature with array



0.4.0 - `Oliphant Chuckerbutty <https://github.com/jvoisin/snuffleupagus/releases/tag/v0.4.0>`__ 2018/08/31
-----------------------------------------------------------------------------------------------------------

New features
^^^^^^^^^^^^

- Add the possibility to whitelist `stream
  wrappers <https://secure.php.net/manual/en/intro.stream.php>`__
- Snuffleupagus is now using php's logging mechanisms, instead of 
  outputting its log directly into the syslog.
- PHP is now prevented from ever disabling certificate verification
  thanks to a few lines in our default configuration.


Improvements
^^^^^^^^^^^^

- Significant code simplification for cookies handling
  thanks to `Remi Collet <http://famillecollet.com>`__
- Our ``sloppy comparison`` feature is now complete
- Snuffleupagus won't start with an invalid config anymore,
  except if the ``sp.allow_broken_configuration`` is set.
- It's now possible to place virtual-patches on the return value
  of user-defined functions.
- Since Snuffleupagus is used by more and more organisations,
  we added a bunch of them in our propaganda page.

Bug fixes
^^^^^^^^^

- Add some missing pieces of documentation and fix some links
- Fix the ``make install`` command
- Fix various compilation warnings
- Snuffleupagus is now running on platforms that aren't using
  the glibc, thanks to an external contributor `Antoine Tenart
  <https://ack.tf>`__



0.3.1 - `Elephant Arch <https://github.com/jvoisin/snuffleupagus/releases/tag/v0.3.1>`__ 2018/08/20
---------------------------------------------------------------------------------------------------

Improvements
^^^^^^^^^^^^

- Disable XXE and harden PRNG by default
- Use ``SameSite`` on PHP's session cookie in the default rules
- Relax a bit what files can be included in the default rules  
- Add the possibility to ignore files hashes when generating rules
- The ``filename`` filter is now accepting phar paths  

Bug fixes
^^^^^^^^^

- The harden rand_feature is not ignoring parameters anymore in function calls
- Fix possible crashes/hangs when using php-fpm's pools  
- Fix an infinite loop on ``echo`` hook
- Fix an issue with ``filename`` filter
- Fix some documentation issues
- Fix the Arch Linux's PKGBUILD


0.3.0 - `Dentalium elephantinum <https://github.com/jvoisin/snuffleupagus/releases/tag/v0.3.0>`__ 2018/07/17
------------------------------------------------------------------------------------------------------------

New features
^^^^^^^^^^^^

- Session cookies can now be `encrypted <https://github.com/jvoisin/snuffleupagus/pull/178>`__
- Some occurrences of `type juggling <https://github.com/jvoisin/snuffleupagus/pull/186>`__ can now be eradicated
- It's  `now possible <https://github.com/jvoisin/snuffleupagus/pull/187>`__ to hook `echo` and `print`

Improvements
^^^^^^^^^^^^

- The `.filename()` filter is `now matching <https://github.com/jvoisin/snuffleupagus/pull/167>`__ on the file where the function is called instead on the one where it's defined.
- Vastly `optimize <https://github.com/jvoisin/snuffleupagus/issues/166>`__ the way we hook native functions
- The format of the logs has been streamlined to ease their processing


Bug fixes
^^^^^^^^^

- Better handling of filters for built-in functions
- Fix various possible integer overflows
- Fix an `annoying memory leak <https://github.com/jvoisin/snuffleupagus/issues/192#issuecomment-404538124>`__ impacting mostly `mod_php`  


0.2.2 - `Elephant Moraine <https://github.com/jvoisin/snuffleupagus/releases/tag/v0.2.2>`__ 2018/04/12
------------------------------------------------------------------------------------------------------

New features
^^^^^^^^^^^^
- The `.dump()` filter is now supported for `unserialize`, `readonly_exec`, and `eval` black/whitelist

Improvements
^^^^^^^^^^^^

- Add some assertions
- Add more rules examples
- Provide a script to check for malicious file uploads
- Significant performances improvement (at least +20%)
- Significantly improve the performances of our default rules set
- Our readme file is now shinier
- Minor code simplification

Bug fixes
^^^^^^^^^
- Fix a crash related to variadic functions


0.2.1 - `Elephant Point <https://github.com/jvoisin/snuffleupagus/releases/tag/v0.2.1>`__ 2018/02/07
----------------------------------------------------------------------------------------------------

Bug fixes
^^^^^^^^^

- The testsuite can now be successfully run as root
- Fix a double execution when snuffleupagus is used with some other extensions
- Fix an execution-context related crash

Improvements
^^^^^^^^^^^^

- Support PCRE2, since it's `required for PHP7.3 <https://wiki.php.net/rfc/pcre2-migration>`__
- Improve a bit the portability of the code
- Minor code simplification

0.2.0 - `Elephant Rally <https://github.com/jvoisin/snuffleupagus/releases/tag/v0.2.0>`__ - 2018/01/18
------------------------------------------------------------------------------------------------------

New features
^^^^^^^^^^^^

- `Glob <https://en.wikipedia.org/wiki/Glob_%28programming%29>`__ support in ``sp.configuration_file``
- Whitelist/blacklist functions in ``eval``
- ``phpinfo`` shows if the configuration is valid or not

Bug fixes
^^^^^^^^^

- Off-by-one in configuration parsing fixed
- Minor cookie-encryption related memory leaks fixes
- Various crashes spotted by `fr33tux <https://fr33tux.org/>`__ fixes
- Configuration files with windows EOL are correctly handled

Improvements
^^^^^^^^^^^^

- General code clean-up
- Documentation overhaul
- Compilation on FreeBSD and CentOS
- Select which cookies to encrypt via regular expressions
- Match on return values from user-defined functions

External contributions
^^^^^^^^^^^^^^^^^^^^^^

- Simplification and clean up of our linked-list implementation by `smagnin <https://github.com/smagnin>`__

0.1.0 - `Mighty Mammoth <https://github.com/jvoisin/snuffleupagus/releases/tag/v0.1.0>`__ - 2017/12/21
------------------------------------------------------------------------------------------------------

- Initial release
