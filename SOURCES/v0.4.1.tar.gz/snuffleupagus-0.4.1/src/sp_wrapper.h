#ifndef SP_WRAPPER_H
#define SP_WRAPPER_H
#include "php_snuffleupagus.h"

void sp_disable_wrapper();
int hook_stream_wrappers();

#endif
